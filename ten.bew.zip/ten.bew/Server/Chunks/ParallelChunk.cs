﻿using ten.bew.Caching;
using i.ten.bew;
using i.ten.bew.Messaging;
using i.ten.bew.Server;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;

namespace ten.bew.Server.Chunks
{
    internal class ParallelChunk : ChunkBase
    {
        private List<ChunkBase> _chunks;
        private Task _initTask;
        private bool _initialised;

        public class Creator : ChunkCreator
        {
            protected internal override ChunkBase Create(IServer server, dynamic parameters)
            {
                var serializedParameter = JsonConvert.SerializeObject(parameters);
                return new ParallelChunk(server, serializedParameter);
            }
        }

        public ParallelChunk(IServer server, string serializedParameter)
            : base(server)
        {
            _initTask = Task.Factory.StartNew(() =>
            {
                PageChunk.PageDescription pageDescription = JsonConvert.DeserializeObject<PageChunk.PageDescription>(serializedParameter);
                _chunks = new List<ChunkBase>();
                PageChunk.BuildChunks(server, _chunks, pageDescription);
                _initialised = true;
            });
        }

        public override async Task Send(HttpClientImpl client, Stream redirectionStream)
        {
            if (_initialised == false)
            {
                await _initTask;
            }

            if (redirectionStream == null)
            {
                redirectionStream = client.Context.Response.OutputStream;
            }

            try
            {
                Task[] tasks = new Task[_chunks.Count];

                for(int i = 0; i < _chunks.Count; i++)
                {
                    var chunk = _chunks[i];
                    
                    MemoryStream outputTo = new MemoryStream();

                    Task task = chunk.Send(client, outputTo).ContinueWith(
                        (previousTask) => 
                        {
                            using (outputTo)
                            {
                                if (previousTask.Status == TaskStatus.RanToCompletion)
                                {
                                    outputTo.Position = 0;

                                    lock (redirectionStream)
                                    {
                                        outputTo.CopyTo(redirectionStream);
                                    }
                                }
                            }
                        }
                    );

                    tasks[i] = task;
                }

                Task.WaitAll(tasks);
            }
            finally
            {
                client.Context.Response.OutputStream.FlushAsync().ContinueWith((t) =>
                {
                    if (SendType == SendTypeEnum.CloseStream)
                    {
                        client.Context.Response.OutputStream.Close();
                    }
                }
                );
            }

        }
    }
}
