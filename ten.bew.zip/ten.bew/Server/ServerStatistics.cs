﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ten.bew.Server
{
    public class ServerStatistics
    {
        public int RunCount;
    }
}
